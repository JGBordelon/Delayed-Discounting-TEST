﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Psych1 {
    public class Trial {

        public int trialNumber;
        public int phaseNumber;
    }
}

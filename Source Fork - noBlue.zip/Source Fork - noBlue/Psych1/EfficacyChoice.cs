﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Psych1
{
    public class EfficacyChoice
    {
        public string choice;
        public double time;

        public EfficacyChoice(string c, double t)
        {
            choice = c;
            time = t;
        }
    }
}

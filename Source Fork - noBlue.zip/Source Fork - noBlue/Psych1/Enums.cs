﻿public enum DelayUnits { 
    Seconds, Minutes, Hours, Days, Weeks, Months, Years
}

public enum TrialTypes {
    DelayDiscount, ChoiceGame
}


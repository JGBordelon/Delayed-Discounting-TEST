﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Psych1 {
    class DelayDiscountTrial : Trial {
        public int trialBlock;
        public int maxMagnitude;
        public int leftMagnitude;
        public int choiceMagnitude;
        public long choiceDelay;
    }
}

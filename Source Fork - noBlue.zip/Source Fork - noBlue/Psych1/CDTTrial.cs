﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Psych1 {
    public class CDTTrial : Trial {
        public bool correct;
        public long responseTime;
        public string testingOrTraining;
    }
}
